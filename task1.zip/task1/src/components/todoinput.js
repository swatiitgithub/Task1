import React, { useState } from 'react';
import './Todo.css'; // Import CSS file for styling

function TodoInput(props) {
    const [inputText, setInputText] = useState('');

    const handleInputChange = (e) => {
        setInputText(e.target.value);
    }

    return (
        <div className="container">
            <div className='row'>
                <div className='input-container'>
                    <div className="col-md-4"></div>
                    <div className="col-md-4"></div>

                    <input
                        type="text"
                        className="input-box-todo"
                        placeholder="Enter your todoinput"
                        value={inputText}
                        onChange={handleInputChange}
                    />
                    <button
                        className='add-btn'
                        onClick={() => {
                            props.addList(inputText)
                            setInputText("")
                        }}
                    >
                        +
                    </button>
                </div>
            </div>
        </div>
    );
}

export default TodoInput;
