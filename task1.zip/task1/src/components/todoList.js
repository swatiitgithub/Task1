import React from 'react';

function TodoList(props) {
  return (
    <li className="list-item" style={{ border: '1px solid #ccc', padding: '10px', marginBottom: '5px' }}>
        {props.item}
        <span className="icons">
          <i className="fa-solid fa-trash-can icon-delete"
          onClick={e=>{
            props.deleteItem(props.index)
          }}></i>
        </span>
      
    </li>
  );
}

export default TodoList;

